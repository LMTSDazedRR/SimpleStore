package com.example.simplestore;

import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class SimpleStore extends JavaPlugin implements CommandExecutor {

    @Override
    public void onEnable() {
        // Save default config if it doesn't exist
        saveDefaultConfig();

        // Register the command executor
        if (getCommand("store") != null) {
            getCommand("store").setExecutor(this);
        }
        
        getLogger().info("SimpleStore has been enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("SimpleStore has been disabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Reload config command option (optional, e.g., /store reload)
        if (args.length > 0 && args[0].equalsIgnoreCase("reload") && sender.hasPermission("simplestore.reload")) {
            reloadConfig();
            sender.sendMessage(ChatColor.GREEN + "SimpleStore config reloaded!");
            return true;
        }

        // Get values from config.yml
        String url = getConfig().getString("store-url", "https://example.com");
        String rawMessage = getConfig().getString("store-message", "&aStore: &b{url}");

        // Format the message colors and replace placeholder
        String formattedMessage = ChatColor.translateAlternateColorCodes('&', rawMessage.replace("{url}", url));

        // Send clickable chat component for players, or plain text for console
        if (sender instanceof Player) {
            Player player = (Player) sender;
            
            // Create a clickable link component
            TextComponent messageComponent = new TextComponent(formattedMessage);
            messageComponent.setClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, url));
            
            player.spigot().sendMessage(messageComponent);
        } else {
            sender.sendMessage(formattedMessage);
        }

        return true;
    }
}